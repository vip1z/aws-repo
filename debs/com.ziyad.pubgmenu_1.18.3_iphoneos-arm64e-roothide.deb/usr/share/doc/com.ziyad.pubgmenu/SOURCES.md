ZIYAD1.18.3 source and verification

This gameplay and interface build excludes the earlier report-suppression
module. It does not implement hiding from anti-cheat or account-ban protection.

The supplied source is ShadowTrackerExtra4.7.0/build21730,
UUID E7164171-7E18-38D9-A445-B95E732117B8,
SHA256 c9e71a8ce57dfd6a2fb508e19b64e0d1fe831d92da47d92c611c507a3b52bbd5.
Runtime preparation compares exact code/member contexts; host tests never
execute the game's code. ActiveWeaponPatches, AimOnFire, PlayerColor and
ColorRenderGate retain gameplay behavior. PlayerFacts proves AI/team/death/
position and optional health/armor/name. MeshParts and LocalPlayerIdentity validate
typed ownership/native ABIs. Teammates default OFF or use cyan under TeamDisplay.

PlayerFacts reads the bounded replicated PlayerName FString with coherent
header/content checks and UTF-16 conversion. This is not a reconstruction of
the game's optional custom/localized HPbar name presentation. The UI shows a
health meter and percentage only when copied current/max health are available;
missing values do not become an invented percentage.

LocalPlayerIdentity retains the verified human body while a typed mounted Pawn
is possessed, checking the source-specific controller/body ownership links.
Radar and PlayerColor use that body for team/self identity and the controlled
mount's verified world position for local distance calculations. Host fixtures
cover car, horse, return to foot, invalid ownership and unavailable transforms.
This does not establish physical iPhone behavior or mounted aim behavior.

Radar projects copied data through native viewport/projection methods.
PlayerEligibility keeps knocked players and rejects hidden/destroying/dead/
eliminated/revival-waiting actors. WeaponFacts/WeaponNames validate ground and
held weapons, use the native display query and destructor, and retain #itemID
when names are unavailable. The shared ground enumeration recognizes only six
source-proven regular medicine IDs (601001, 601002, 601003, 601004, 601005,
601006), with a negative native
weapon classification also required; it does not infer medicines by a numeric
range. Special-event and unknown consumables remain excluded.

The current RadarIcons.bundle model manifest records 72 weapon-model photos
and 6 medicine images. Sources are official PUBG: BATTLEGROUNDS weapon pages,
the official PUBG API assets repository pinned at commit
32b13b51128b8d8909ae5e77f3b833e01230b24d, and the public official PUBG MOBILE
weapon wiki. Individual URLs, source/processed hashes, dimensions and known
coverage gaps are in RadarIcons.bundle/model-manifest.json; attribution and
usage-source references are in RadarIcons.bundle/ASSET-SOURCES.txt. No new
license or ownership is asserted. The original SCAR-L and M249 downloads are
byte-identical to the user's supplied reference files, as recorded in the
manifest. Alpha-bound trimming and downsampling preserve color and alpha,
with a maximum output size of 512x256 and no enlargement. These are base-model
images, not a guarantee of live PUBG MOBILE skins or attachments.

RadarWeaponPhotos and RadarIcons select weapon model photos through explicit native
item-name/asset-key aliases. Unknown or conflicting weapon matches have no
substitute image; names or #itemID remain available. This is not complete
weapon coverage: M1 Garand and any other unlisted model have no photo fallback.
The two source-default medicine IDs named Medical1/Medical2 are not guessed
to mean first aid or med kit: those photos require an explicit name/path match.
Item asset paths are treated as matching keys, not arbitrary filesystem paths.

The current object presentation supersedes the1.10.0 displaced-label design.
All item/vehicle/crate images stay immediately above their copied native anchor;
there are no item leaders, dots or side displacement. The user explicitly chose
smaller images nearby:24x12pt bounds at<=5m, smooth interpolation to44x20pt at80m,
with an8pt name above and distance below. Missing photos keep only the name,
without the repeated unavailable-image caption. Held labels are compact too.
Native counts/ranges and player-line controls are unchanged; no new visibility
culling is introduced. True coincident projections can still overlap. The old
label-layout utility remains for historical fixture compatibility but is not
called by the current UI. Photo-scale tests exercise current behavior.

VehicleFacts validates STExtraVehicleBase, the110-entry source shape enum and
five health states before use. It reads typed identities, lifecycle and root
ownership; destroyed/exploded states are excluded. Enumeration runs at4Hz and
positions are refreshed before each existing projection pass. Models are source
enum names, not guessed numeric IDs. The own controlled mount is omitted.
VehicleFacts-source-proof.json and tests include source mutation/ASLR evidence;
this does not establish physical phone performance or drivability information.

RadarWorldPhotos maps source names to26 official Mobile vehicle base-family
photos and2 role-specific crate cutouts. Roof/paint/cargo variants can differ;
unknown special vehicle shapes receive no substitute model. Per-file URLs,
hashes, source aliases and credits are in world-model-manifest.json. The death
box reference is by Rex (@rex_7), CC BY4.0, with a credited imagegen-assisted
background extraction. The airdrop reference/usage source is also recorded.
These crate images are edited derivatives and are not pixel-identical or live
cosmetic captures. Full built-in tool edit prompts and saved relative output
paths are in world-image-edit-prompts.json. Third-party art is outside the
original-code MIT license.

CrateFacts accepts explicit death/airdrop enumtypes
only. Crates never enter player-line snapshots. UI receives copied values only.

ItemFilterCatalog and RadarFilterStore add presentation-only filtering over
bounded copied markers. Catalogs contain72 weapon photos,6 medicines and24
supported vehicle base families; unproven roof-specific choices are excluded.
Ground/held weapon presentation shares a filter, while medicine and vehicle
selection stay independent. Defaults show All. Tapping a tile from All starts
a one-item selection, later taps toggle multiple items; All preserves the last
selected set. An empty specific selection shows nothing in its category. Unknown
models in the previous categories appear only in All. Added loot categories
require a recognized complete model name/asset. Crates have independent choices
and range. Filters operate over copied data; range is now a separate UI gate.

Stable catalog keys/modes persist in NSUserDefaults, validated on load. Search
browses image choices without changing hidden selections. Lobby gating turns
off effective controls without erasing saved choices. Global feature-OFF keeps
item preferences. Host Foundation tests use in-memory fake defaults only.
The enlarged nine-tab panel has a750pt maximum width, uses four-column native
UICollectionView pages, and borrows/restores key-window status only for search.
Search/keyboard gestures are compiled/reviewed, not physically phone-tested.

Explicit whole Arabic medicine-name aliases support the six known photos, with
space/diacritic/tatweel normalization and existing truncation/conflict guards.
They are semantic aliases, not proof of every localization string. Medical1/2
numeric IDs remain unassigned to FirstAid/MedKit without actual name/path
evidence; generic Arabic treatment words never guess the medicine type.

MatchState checks current typed GameState, initialized distinct opaque match
names and result flags. GameplaySession closes outside fresh InProgress and
requests synchronous serialized VM restoration. SessionExitHook runs before
the original normal/seamless ClientTravelInternal notification; this is not
proof all abnormal shutdown or unrelated OpenLevel paths invoke it. Native
color restoration is requested while the old world is live; heartbeat and
unknown-state gating remain fallback. The exit latch requires a new verified
world. SessionProfile restores the saved profile once per allowed entry.

Adjacent proof JSONs, source include tables, notes and mock/source tests record
evidence/limits. Physical phone appearance, transition timing, replication
completeness and frame cost remain unverified. Remote security behavior is not
assessed. New source contains no report-suppression module.

The supplied1.6.2 main matched the prior build exactly. Its extra ZiyadGuard has
no supplied source. integrity_guard_package.py binds its audited digest, updates
only own-payload hash strings, signs a temporary copy and verifies both slices
and unchanged instruction sections. This is own-file integrity. Reproducing it
requires the original guard artifact. Original IPA/executable/DEB stay intact.

build.py compiles both iOS architectures with warnings as errors, runs host
tests, checks signatures and independently reopens the DEB. Release verification
checks payload digests, bundle scope and source-archive contents.

1.13.0 item catalogs/ranges and grass density
-------------------------------------------
Seven item categories now have independent persisted25..500m UI gates (default200),
All/multi-selection and range controls above search. Navigation uses nine scrollable
native tabs with explicit LTR geometry and Arabic labels. Ground/held filters share
a range; player/counter/color ranges are unchanged. Crates now use their own page,
image choices and range. ItemFilterCatalog/Store tests cover persistence, numeric
bounds, empty selections, malformed preferences and all marker routes.

Added22 alpha-preserving PNG references from official pubg/api-assets pinned commit
32b13b51128b8d8909ae5e77f3b833e01230b24d:8scope,3helmet,3backpack,8ammunition.
RadarIcons.bundle/loot-model-manifest.json records exact URLs/blob hashes, source
and processed SHA256s and crop metadata. Visual PC asset labels are not evidence of
Mobile numeric IDs. RadarLootPhotos matches only complete copied semantic names or
whitelisted full asset components, with bounded strings/conflict rejection and no
ID guessing. Decimal calibers are distinct. Native extra pickup classification
requires unique category evidence under existing typed/live24-byteID guards;
unsupported names/locales/models remain excluded. Source native category203/301
semantics were not established and are not inferred. See WeaponFacts notes.

GrassRenderGate uses only source-proven grass.densityScale registration, float
setter/typed accessor and density multiplication consumer. A fraction of the
captured original stable value is requested on validated local-controller game
thread ticks. Existing priority and native render synchronization are retained;
OFF/session-exit requests restore owned changes. Wrong-thread, source/identity/
read/priority/value conflicts reject instead of overwriting.758 source bytes and
five vtable slots are covered by fixture-mutation tests, plus ASan/UBSan.
See GrassRenderGate-notes.md for byte/LLVM evidence and analysis-provider limits.

No building/tree/terrain changes are included: broad view-distance/detail controls
do not establish the requested buildings-last ordering or terrain preservation.
Grass regeneration timing, actual installed item display strings and physical
iPhone visual effects are unverified. AppKit previews are illustrative UI layouts,
not captures of the game or UIKit on a phone.

1.14.0 loaded contents
----------------------
ContainerContents/ContentsRadar add source-validated cached crate and player
inventory readers, independently saved content filters/range and picture/count
panels. Read ContainerContents-notes.md for exact schema/member/getter provenance
and limits. Zero arrays are unavailable rather than asserted empty. Full remote
inventory replication and unopened-container availability are not established.
No server request, UI-open or forced replication operation is added. Host tests
run only mocked data/source-byte fixtures. Native UIKit/phone effects unverified.

1.15.0 knock status and offscreen directions
-----------------------------------------
PlayerFacts adds independently validated HealthStatus/last-breath state and typed
current/max downed meter. See updated PlayerFacts proof/notes and336 mutation
guards (164 core +172 optional). OrdinaryHP0 is not a knock test; missing downed
values never fall back to ordinaryHP or100. CameraFacts adds final cached camera
pose with typed reciprocal ownership/coherent reads and232 source-byte guards.
The source native FRotator.Vector/matrix arithmetic independently confirms the
RadarEdge forward/right basis. Behind indicators are a360 bearing compass; front
outside-view rays use original native projected pixels. Both clip from the actual
viewport center into a HUD-safe rectangle. Radar integration tests cover state/
meter transitions, camera loss, rear/yaw and original counting behavior. These
paths are read-only, reuse the existing validated callback and do not open items,
change camera/players or alter remote data. Physical-iPhone output unverified.

1.15.1 picked-up ground-item image cleanup
- Ground facts now reject Actor.bHidden and bActorIsBeingDestroyed, with two
  coherent masked reads and identity checks during collection and every cached
  projection pass; prior full item/pickup/count/root checks remain.
- Exact-source named setters06BD8194/06BD8008 are reused from existing crate/
  player evidence and added to WeaponFacts pickup guards (524bytes total).
- Ground categories all share the lifetime gate; partial positive stacks remain
  eligible, and returned items are not permanently blacklisted.
- Host regression tests cover retained wrappers, torn/read-failed state, changes
  during presentation, category independence and cache omission before the next
  enumeration. No physical-iPhone gameplay was tested.

1.16.0 physical airborne drops and notice integration
- Physical AirDropBoxActor and PlayerTombBox replace standalone loot-proxy
  icon classification. New exact-source member/class/native bool contexts are
  recorded in CrateFacts-source-proof.json and gated before native collection.
- Live visual positions and known falling state refresh before each projection;
  linked air/tomb representations are deduplicated and contents use only a
  revalidated typed wrapper link, never physical actor+wrapper offsets.
- Scalar-only AirdropNotice module retains256 identities per gameplay generation,
  consumes landed baselines, never evicts to retrigger, groups new falling
  observations and rejects invalid/regressing time and values. UIKit receives
  a5-second notice and may announce it once through VoiceOver.
- Drops bypass the death-box distance preference; selection and master control
  still apply. Missing camera suppresses edge direction, not notice collection.
  Physical actor replication is still required; no server-global claim.
- Missing photo loads retry after2seconds with role-specific SF Symbols while
  unavailable. world-tomb/world-airdrop successful photo cache keys remain distinct.
- REA bound the exact source identity but deep providers were unavailable in
  this session. New native schema work used explicitly labeled local fixture
  reflection records, original bytes and Xcode LLVM disassembly; no game
  execution or installation was performed.

1.17.0 current ownership filter and body armor loot
- LocalOwnedItems reads current typed bag definitions/counts without the24-item
  display cap; actual equipped/holstered weapon models supplement bag evidence.
  Coherent logical avatar definitions establish equipped gear rather than
  cosmetic item integers. Native configured queries establish actual level.
- Current condition follows source hashed body-part rows; maximum comes from a
  present named Item.Durability table row/property. Missing rows cannot become
  full health; dual fallback predicate availability inference was rejected.
- LocalOwnedItems-source-proof.json records97 contexts/7512 guarded bytes,
  per-feature optional readiness and relocated pointers. Host tests substitute
  native calls and mutate every guarded byte. No target code is executed.
- SmartLootRules is pure copied-data policy; OwnedLootFilter supplies native
  ownership/session/request/owner/freshness gates and250ms copied UI expiry.
  Ground filtering occurs before publication; contents panels use the same
  current snapshot. Native missing data preserves ordinary markers.
- Native configured1..3 gear levels keep upgrades visible. Same-tier damage
  boundary is max-current>=0.5, from original full checks; no made-up maximum.
- Three body armor image references from PUBG api-assets pinned commit
  32b13b51128b8d8909ae5e77f3b833e01230b24d, Equipment/Vest; verified Git blob SHA1
  plus original/processed SHA256 recorded in loot-model-manifest.json. These are
  visual/name references, not evidence of Mobile numeric IDs.
  Source: https://github.com/pubg/api-assets/tree/32b13b51128b8d8909ae5e77f3b833e01230b24d/Assets/Item/Equipment/Vest
- Loaded magazine ammunition and every possible equipped attachment are not
  independently claimed beyond positive current bag/weapon-slot evidence.
  Actual physical-iPhone behavior remains unverified.

## Replicated bot facts and drop/team display (1.18.0)

PlayerFacts-source-proof.json retains the exact original reflected Pawn.PlayerState
and PlayerState.bIsABot identities, native bit consumer, class cache source and
148 independent optional guarded bytes. False nonreplicated actor flags alone
remain unknown. The prior replicated downed-current guards remain unchanged.

CrateFacts-source-proof.json retains36 optional original bytes for the replicated
normal/super flag, typed full-identity linked tomb provenance and conservative
UNKNOWN/NORMAL/SPECIAL labels. Native flare-call evidence enters the super route,
but no replicated physical box-to-calling-plane order ID is established; exclusive
flare provenance is not claimed.

ContainerContents snapshots now retain all24 item identity bytes, whole-list
coherence and opaque wrapper/selected-route identities. Unloaded zero is not
certified empty. DropLoot compares only complete coherent client-cached positive
observations, without server requests, native UI opening, proximity inference or
filter-based disappearance. Source/route replacement and option gaps rebaseline.
TeamGroups uses copied actual TeamIDs and unique player keys; counters describe
observed eligible actors, not server-wide squads. No fixed four-member count.

## LOS warning and crate captions (1.18.1)

The existing source-proven local Controller.LineOfSightTo ABI and exact virtual
implementation are reused before rear/offscreen marker publication. This is
local geometric line of sight, not observed enemy attention or facing. No new
game offsets or game-memory modifications are introduced for this display fix.
RadarLineStyle owns a pure bounded session palette and shared red-priority rule.
Crate-caption collision handling operates on copied screen-space labels only;
all original native identities and image anchors remain unchanged.

## Menu tab-strip navigation (1.18.2)

The local iOS SDK UIScrollView header documents that touch cancellation defaults
to NO for UIControl content. A strip-only subclass permits cancellation for the
segmented control and its descendants; default touch delay remains in place so
a scroll gesture can win before segment activation.44pt explicit page arrows
call the existing page-change handler, preserving keyboard dismissal. Centering
is clamped and limited to page/size changes. No game reader, patch or radar
producer changes are included. Device gesture behavior remains unverified.

## Single total counter HUD (1.18.3)

The existing UI selected `ZMNearbyPlayers.humans`, omitting unknown-type
characters from the headline number even when `total` was nonzero. The label
now reads the existing `total` field, independent of optional type evidence.
The separate bot UILabel and accessibility element are removed; the remaining
number spans and centers in the original HUD width. Unavailable snapshots still
show an em dash, while an available empty census shows zero. The existing
count-only radius, source selection, refresh timer, team count and native
implementation are unchanged. Host validation does not establish physical
iPhone rendering.
